<div class="sidebar" data-color="orange" data-background-color="black" data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="<?php echo e(route('home')); ?>" class="simple-text logo-normal">
    <img src="<?php echo e(asset('material')); ?>/img/logo.png" alt="" width="130">
      <!-- <?php echo e(__('Innova Sur Pro')); ?> -->
    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="material-icons">dashboard</i>
            <p><?php echo e(__('Panel Administración')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'reservas' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('reserva.index')); ?>">
          <i class="material-icons">content_paste_go</i>
            <p><?php echo e(__('Gestión De Reservas')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'evento' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('evento.index')); ?>">
          <i class="material-icons">insert_invitation</i>
          <p><?php echo e(__('Calendario Reservas')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'condominios' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('condominio.index')); ?>">
          <i class="material-icons">apartment</i>
            <p><?php echo e(__('Gestión De Condominios')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'user' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
          <i class="material-icons">manage_accounts</i>
            <p><?php echo e(__('Gestión de usuarios')); ?></p>
        </a>
      </li>
      <!-- <li class="nav-item <?php echo e(($activePage == 'profile' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" data-toggle="collapse" href="#laravelExample" aria-expanded="false"> -->
          <!-- <i><img style="width:25px" src="<?php echo e(asset('material')); ?>/img/laravel.svg"></i> -->
          <!-- <i class="material-icons">manage_accounts</i>
          <p><?php echo e(__('Gestión de usuarios')); ?>

            <b class="caret"></b> -->
          </p>
        </a>
        <!-- <div class="collapse show" id="laravelExample">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'profile' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>"> -->
                <!-- <span class="sidebar-mini"> UP </span> -->
                <!-- <i class="material-icons">account_circle</i>
                <span class="sidebar-normal"><?php echo e(__('Modificar su perfil')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'user' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('user.index')); ?>"> -->
                <!-- <span class="sidebar-mini"> UM </span> -->
                <!-- <i class="material-icons">group</i>
                <span class="sidebar-normal"> <?php echo e(__('Modificar Usuarios')); ?> </span>
              </a>
            </li>
          </ul>
        </div>
      </li> -->
      <li class="nav-item<?php echo e($activePage == 'table' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('table')); ?>">
          <i class="material-icons">insert_invitation</i>
            <p><?php echo e(__('Table List')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'typography' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('typography')); ?>">
          <i class="material-icons">library_books</i>
            <p><?php echo e(__('Typography')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'icons' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('icons')); ?>">
          <i class="material-icons">bubble_chart</i>
          <p><?php echo e(__('Icons')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'map' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('map')); ?>">
          <i class="material-icons">location_ons</i>
            <p><?php echo e(__('Maps')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'notifications' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('notifications')); ?>">
          <i class="material-icons">notifications</i>
          <p><?php echo e(__('Notifications')); ?></p>
        </a>
      </li>
      <li class="nav-item active-pro<?php echo e($activePage == 'logout' ? ' active' : ''); ?>">
        <a class="nav-link text-white bg-danger" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
          <i class="material-icons text-white">logout</i>
          <p><?php echo e(__('Cerrar Sesión')); ?></p>
        </a>
      </li>
    </ul>
  </div>
</div>
<?php /**PATH C:\laragon\www\reservas_laravel_8\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>