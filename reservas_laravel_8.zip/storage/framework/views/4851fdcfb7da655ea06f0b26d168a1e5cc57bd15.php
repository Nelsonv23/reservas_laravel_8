

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <form method="post" action="<?php echo e(route('reserva.store')); ?>" autocomplete="off" class="form-horizontal">
          <?php echo csrf_field(); ?>

          <div class="card ">
            <div class="card-header card-header-primary">
              <h4 class="card-title"><?php echo e(__('Crear nueva reserva')); ?></h4>
              <p class="card-category"><?php echo e(__('Complete el formulario para crear una nueva reserva')); ?></p>
            </div>
            <div class="card-body ">
              <?php if(session('status')): ?>
              <div class="row">
                <div class="col-sm-12">
                  <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                    <span><?php echo e(session('status')); ?></span>
                  </div>
                </div>
              </div>
              <?php endif; ?>
              <div class="row">
                <label class="col-sm-2 col-form-label"><?php echo e(__('Departamento')); ?></label>
                <div class="col-sm-7">
                  <div class="form-group<?php echo e($errors->has('departamento') ? ' has-danger' : ''); ?>">
                    <input class="form-control<?php echo e($errors->has('departamento') ? ' is-invalid' : ''); ?>" name="departamento" id="input-departamento" type="text" placeholder="<?php echo e(__('Departamento')); ?>" value="<?php echo e(old('departamento')); ?>" required="true" aria-required="true" />
                    <?php if($errors->has('departamento')): ?>
                    <span id="departamento-error" class="error text-danger" for="input-departamento"><?php echo e($errors->first('departamento')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <!-- Select Condominio -->
              <div class="row">
                <label class="col-sm-2 col-form-label"><?php echo e(__('Condominio')); ?></label>
                <div class="col-sm-7">
                  <div class="form-group<?php echo e($errors->has('condominio') ? ' has-danger' : ''); ?>">
                    <select class="form-control<?php echo e($errors->has('condominio') ? ' is-invalid' : ''); ?>" name="condominio" id="select-condominio" type="text" value="<?php echo e(old('condominio')); ?>" required >
                    <option disabled selected>Seleccione</option>
                        <?php $__currentLoopData = $condominios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condominio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($condominio->nombre); ?>"><?php echo e($condominio->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select >
                    <?php if($errors->has('condominio')): ?>
                    <span id="condominio-error" class="error text-danger" for="input-condominio"><?php echo e($errors->first('condominio')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <!-- Fin Select Condominio -->
              <div class="row">
                <label class="col-sm-2 col-form-label"><?php echo e(__('Fecha')); ?></label>
                <div class="col-sm-7">
                  <div class="form-group<?php echo e($errors->has('fecha') ? ' has-danger' : ''); ?>">
                    <input class="form-control<?php echo e($errors->has('fecha') ? ' is-invalid' : ''); ?>" name="fecha" id="input-fecha" type="date" placeholder="<?php echo e(__('Fecha')); ?>" value="<?php echo e(old('fecha')); ?>" required />
                    <?php if($errors->has('fecha')): ?>
                    <span id="fecha-error" class="error text-danger" for="input-fecha"><?php echo e($errors->first('fecha')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-footer ml-auto mr-auto">
              <button type="submit" class="btn btn-primary"><?php echo e(__('Guardar')); ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'reservas', 'titlePage' => __('Crear Reserva')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\reservas_laravel_8\resources\views/reserva/create.blade.php ENDPATH**/ ?>