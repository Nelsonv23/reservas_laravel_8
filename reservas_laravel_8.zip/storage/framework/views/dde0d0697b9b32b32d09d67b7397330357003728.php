

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-12 text-left">
                        <a href="<?php echo e(route('condominios.create')); ?>" class="btn btn-info">
                            <i class="material-icons">add_circle</i> Nuevo Condominio</a>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title ">Condominios Temuco</h4>
                        <p class="card-category"> Listado De Condominios Temuco</p>
                    </div>
                    <div class="card-body">
                        <?php if(session('success')): ?>
                        <div class="alert alert-success" role="success">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead class=" text-primary">
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Dirección</th>
                                    <th>Ciudad</th>
                                    <th>Acciones</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $condominios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condominio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td> <?php echo e($condominio->id); ?> </td>
                                        <td> <?php echo e($condominio->nombre); ?> </td>
                                        <td> <?php echo e($condominio->direccion); ?> </td>
                                        <td> <?php echo e($condominio->ciudad); ?> </td>
                                        <td>
                                            <form action="<?php echo e(route('condominios.destroy', $condominio->id)); ?>" method="post">
                                                <a href="<?php echo e(route('condominios.edit', $condominio->id)); ?>" class="btn btn-warning">Editar</a>
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-danger" type="submit">Borrar</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'condominios', 'titlePage' => __('Gestión De Condominios')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\reservas_laravel_8\resources\views/condominio/index.blade.php ENDPATH**/ ?>