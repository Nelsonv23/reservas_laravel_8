

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="POST" action="<?php echo e(route('condominio.update', $condominio->id)); ?>" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Editar Condominio')); ?></h4>
                <p class="card-category"><?php echo e(__('Complete el formulario para editar una condominio')); ?></p>
              </div>
              <div class="card-body ">
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Nombre')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('nombre') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="nombre" id="input-nombre" type="text" value="<?php echo e($condominio->nombre); ?>" required />
                      <?php if($errors->has('nombre')): ?>
                        <span id="nombre-error" class="error text-danger" for="input-nombre"><?php echo e($errors->first('nombre')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Dirección')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('direccion') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('direccion') ? ' is-invalid' : ''); ?>" name="direccion" id="input-direccion" type="text" value="<?php echo e($condominio->direccion); ?>" required />
                      <?php if($errors->has('direccion')): ?>
                        <span id="direccion-error" class="error text-danger" for="input-direccion"><?php echo e($errors->first('direccion')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Ciudad')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('ciudad') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('ciudad') ? ' is-invalid' : ''); ?>" name="ciudad" id="input-ciudad" type="text" value="<?php echo e($condominio->ciudad); ?>" required />
                      <?php if($errors->has('ciudad')): ?>
                        <span id="ciudad-error" class="error text-danger" for="input-ciudad"><?php echo e($errors->first('ciudad')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Guardar')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'condominios', 'titlePage' => __('Editar Condominio')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\reservas_laravel_8\resources\views/condominio/edit.blade.php ENDPATH**/ ?>