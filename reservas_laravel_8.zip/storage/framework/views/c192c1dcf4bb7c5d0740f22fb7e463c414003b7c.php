<footer class="footer">
  <!-- <div class="container-fluid">
    <nav class="float-left">
      <ul>
        <li>
          <a href="#">
              <?php echo e(__('Creative Tim')); ?>

          </a>
        </li>
        <li>
          <a href="#">
              <?php echo e(__('About Us')); ?>

          </a>
        </li>
        <li>
          <a href="#">
              <?php echo e(__('Blog')); ?>

          </a>
        </li>
        <li>
          <a href="#">
              <?php echo e(__('Licenses')); ?>

          </a>
        </li>
      </ul>
    </nav>
    <div class="copyright float-right">
      &copy;
      <script>
        document.write(new Date().getFullYear())
      </script>, Realizado <i class="material-icons">favorite</i> por
      <a href="https://www.novenaweb.cl" target="_blank">NOVENAWEB</a> for a better web.
    </div>
  </div> -->
</footer><?php /**PATH C:\laragon\www\reservas_laravel_8\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>